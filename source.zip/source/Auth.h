﻿#pragma once
#ifndef AUTH_H
#define AUTH_H
#define CURL_STATICLIB
#include <string>
#include <windows.h>
#include <Wbemidl.h>
#include <comdef.h>
#include <curl/curl.h>
#include "Cfg/nlohmann/json.hpp"
#include "Cfg/strenc.h"
#include "Imports/Scope.h"
#include "http.h"
#include <shlobj.h>


using json = nlohmann::json;
std::string GetDesktopPath() {
    char path[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathA(NULL, CSIDL_DESKTOP, NULL, 0, path))) {
        return std::string(path) + "\\login_debug.txt";
    }
    return "login_debug.txt"; // fallback
}

void WriteLog(const std::string& content) {
    std::string logPath = GetDesktopPath();
    std::ofstream logFile(logPath, std::ios::app);
    if (logFile.is_open()) {
        logFile << content << "\n";
        logFile.close();
    }
}
void SendHeartbeat() {
    if (!Auth.Autenticado || Auth.Usuario[0] == '\0') {
        //WriteLog("Heartbeat ignorado: usuário não autenticado.");
        return;
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        WriteLog("Falha ao inicializar CURL no Heartbeat.");
        return;
    }

    std::string url = "http://164.152.47.173/api/heartbeat";
    json post_data = { {"username", Auth.Usuario} };
    std::string post_data_str = post_data.dump();

    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");

    // ✅ Use sempre a mesma API key do servidor (abc123)
    std::string apiKeyHeader = "X-API-KEY: abc123";
    headers = curl_slist_append(headers, apiKeyHeader.c_str());

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data_str.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 5L);

    CURLcode res = curl_easy_perform(curl);

    if (res != CURLE_OK) {
       // WriteLog("Heartbeat error: " + std::string(curl_easy_strerror(res)));
    }
    else {
        //WriteLog("Heartbeat enviado com sucesso para o usuário: " + std::string(Auth.Usuario));
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
}

void HeartbeatThread() {
   // WriteLog("Thread de heartbeat iniciada.");
    while (true) {
        SendHeartbeat();
        std::this_thread::sleep_for(std::chrono::seconds(30));
    }
}










static size_t AuthWriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    size_t total_size = size * nmemb;
    ((std::string*)userp)->append((char*)contents, total_size);
    return total_size;
}

std::string GenerateHWID() {
    HRESULT hres;
    std::string hwid_part1, hwid_part2;

    hres = CoInitializeEx(0, COINIT_MULTITHREADED);
    if (FAILED(hres)) {
        WriteLog("CoInitializeEx failed");
        return "";
    }

    IWbemLocator* pLoc = nullptr;
    IWbemServices* pSvc = nullptr;

    hres = CoCreateInstance(CLSID_WbemLocator, 0, CLSCTX_INPROC_SERVER, IID_IWbemLocator, (LPVOID*)&pLoc);
    if (FAILED(hres)) {
        WriteLog("CoCreateInstance failed");
        CoUninitialize();
        return "";
    }

    hres = pLoc->ConnectServer(_bstr_t(L"ROOT\\CIMV2"), NULL, NULL, 0, NULL, 0, 0, &pSvc);
    if (FAILED(hres)) {
        WriteLog("ConnectServer failed");
        pLoc->Release();
        CoUninitialize();
        return "";
    }

    IEnumWbemClassObject* pEnumerator = nullptr;
    hres = pSvc->ExecQuery(bstr_t("WQL"), bstr_t("SELECT * FROM Win32_Processor"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, NULL, &pEnumerator);
    if (SUCCEEDED(hres)) {
        IWbemClassObject* pclsObj = nullptr;
        ULONG uReturn = 0;
        while (pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn) == S_OK) {
            VARIANT vtProp;
            VariantInit(&vtProp);
            if (SUCCEEDED(pclsObj->Get(L"ProcessorId", 0, &vtProp, 0, 0))) {
                hwid_part1 = _bstr_t(vtProp.bstrVal);
            }
            VariantClear(&vtProp);
            pclsObj->Release();
        }
        pEnumerator->Release();
    }

    hres = pSvc->ExecQuery(bstr_t("WQL"), bstr_t("SELECT * FROM Win32_DiskDrive"),
        WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY, NULL, &pEnumerator);
    if (SUCCEEDED(hres)) {
        IWbemClassObject* pclsObj = nullptr;
        ULONG uReturn = 0;
        while (pEnumerator->Next(WBEM_INFINITE, 1, &pclsObj, &uReturn) == S_OK) {
            VARIANT vtProp;
            VariantInit(&vtProp);
            if (SUCCEEDED(pclsObj->Get(L"SerialNumber", 0, &vtProp, 0, 0))) {
                hwid_part2 = _bstr_t(vtProp.bstrVal);
            }
            VariantClear(&vtProp);
            pclsObj->Release();
        }
        pEnumerator->Release();
    }

    if (pSvc) pSvc->Release();
    if (pLoc) pLoc->Release();
    CoUninitialize();

    std::string hwid = hwid_part1 + "-" + hwid_part2;
    WriteLog("HWID: " + hwid);

    return hwid.empty() ? "unknown" : hwid;
}




bool PerformLogin(const std::string& username, const std::string& hwid, std::string& error_message) {
    CURL* curl;
    CURLcode res;
    std::string response_string;

    curl_global_init(CURL_GLOBAL_ALL);
    curl = curl_easy_init();
    if (!curl) {
        error_message = "Falha ao inicializar CURL.";
        curl_global_cleanup();
        return false;
    }

    std::string url = "http://164.152.47.173/api/login";

    json post_data = {
        {"username", username},
        {"hwid", hwid},
        {"loader_hash", Auth.LoaderHash} // Você já tem o loader_hash aqui
    };
    std::string post_data_str = post_data.dump();

    //WriteLog("POST DATA: " + post_data_str);

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data_str.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, post_data_str.length());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, AuthWriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_string);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);

    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");

    // --- INÍCIO DA CORREÇÃO ---
    // Adicione o cabeçalho de autenticação.
    // O valor "abc123" deve ser o mesmo que o servidor espera.
    std::string apiKeyHeader = "X-API-KEY: " + Auth.LoaderHash;
    headers = curl_slist_append(headers, apiKeyHeader.c_str());
    // --- FIM DA CORREÇÃO ---

    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

    res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        error_message = "Falha na requisição: " + std::string(curl_easy_strerror(res));
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        WriteLog("Erro CURL: " + error_message);
        return false;
    }

    long response_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);

    //WriteLog("HTTP Response Code: " + std::to_string(response_code));
    WriteLog("Information: " + response_string);

    // Tenta extrair mensagem de erro mesmo que HTTP != 200
    try {
        json response_json = json::parse(response_string);
        if (!response_json["success"].get<bool>()) {
            error_message = response_json["message"].get<std::string>();
            curl_slist_free_all(headers);
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return false;
        }

        // Se sucesso, preenche Auth e retorna true
        Auth.Autenticado = true;
        Auth.SessionToken = response_json["data"]["session_token"].get<std::string>();
        std::string userStr = response_json["data"]["username"].get<std::string>();
        strncpy_s(Auth.Usuario, userStr.c_str(), sizeof(Auth.Usuario));
        Auth.Usuario[sizeof(Auth.Usuario) - 1] = '\0';

        std::string expires_at = response_json["data"]["expires_at"].get<std::string>();

        int day, month, year, hour, min, sec;
        if (sscanf_s(expires_at.c_str(), "%d/%d/%d %d:%d:%d", &day, &month, &year, &hour, &min, &sec) == 6) {
            SYSTEMTIME current_time;
            GetLocalTime(&current_time);

            FILETIME ft_current, ft_expires;
            SYSTEMTIME st_expires = { (WORD)year, (WORD)month, 0, (WORD)day, (WORD)hour, (WORD)min, (WORD)sec, 0 };

            SystemTimeToFileTime(&current_time, &ft_current);
            SystemTimeToFileTime(&st_expires, &ft_expires);

            ULARGE_INTEGER ul_current, ul_expires;
            ul_current.LowPart = ft_current.dwLowDateTime;
            ul_current.HighPart = ft_current.dwHighDateTime;
            ul_expires.LowPart = ft_expires.dwLowDateTime;
            ul_expires.HighPart = ft_expires.dwHighDateTime;

            LONGLONG diff = (ul_expires.QuadPart - ul_current.QuadPart) / (10LL * 1000 * 1000 * 60 * 60 * 24);
            Auth.dias_restantes = static_cast<int>(diff > 0 ? diff : 0);
        }

        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return true;
    }
    catch (const json::exception& e) {
        // Se JSON inválido, cai aqui e continua para erro genérico HTTP
    }

    // Se não conseguiu extrair erro da resposta JSON, usa mensagem genérica para HTTP != 200
     // --- INÍCIO DA CORREÇÃO ---

    // Primeiro, verificamos se o código de status HTTP é 200 (OK)
    if (response_code != 200) {
        // Se não for 200, tentamos extrair uma mensagem de erro do JSON
        try {
            json response_json = json::parse(response_string);
            if (response_json.contains("error")) {
                error_message = response_json["error"].get<std::string>();
            }
            else {
                error_message = "Erro desconhecido com código " + std::to_string(response_code);
            }
        }
        catch (const json::exception&) {
            // Se a resposta de erro não for um JSON válido
            error_message = "Erro " + std::to_string(response_code) + ": Resposta inválida do servidor.";
        }
        return false; // Login falhou
    }

    // Se o código for 200, a resposta deve ser um JSON de sucesso
    try {
        json response_json = json::parse(response_string);

        // Verificamos se o status é "ok" e se o username corresponde
        if (response_json.contains("status") && response_json["status"] == "ok" &&
            response_json.contains("username") && response_json["username"] == username)
        {
            // Preenche a estrutura Auth com os dados recebidos
            Auth.Autenticado = true;

            // Copia o nome de usuário para a estrutura Auth
            std::string userStr = response_json["username"].get<std::string>();
            strncpy_s(Auth.Usuario, userStr.c_str(), sizeof(Auth.Usuario) - 1);
            Auth.Usuario[sizeof(Auth.Usuario) - 1] = '\0'; // Garante terminação nula

            // Como a API atual não retorna token de sessão ou data de expiração,
            // podemos deixar esses campos vazios ou com valores padrão.
            Auth.SessionToken = ""; // Não há token na resposta atual
            Auth.dias_restantes = 999; // Valor padrão, já que a API não envia isso

            // Se chegou até aqui, o login foi um sucesso.
            return true;
        }
        else {
            // O JSON de sucesso não tem o formato esperado
            error_message = "Resposta de sucesso inesperada do servidor.";
            return false;
        }
    }
    catch (const json::exception& e) {
        // A resposta de sucesso não era um JSON válido
        error_message = "Falha ao analisar a resposta do servidor: " + std::string(e.what());
        return false;
    }


    // Se chegou aqui, algo estranho aconteceu — considera sucesso?
    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    curl_global_cleanup();
    return false;
}






#endif
