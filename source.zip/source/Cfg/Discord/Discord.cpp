#define _CRT_SECURE_NO_WARNINGS
#include "Discord.h"
#include <time.h>
#include <chrono>
#include "Discord SDK/discord_rpc.h"
#include "../strenc.h"

static int64_t eptime = std::chrono::duration_cast<std::chrono::seconds>(
    std::chrono::system_clock::now().time_since_epoch()
).count();

void Discord::Initialize() {
    DiscordEventHandlers Handle;
    memset(&Handle, 0, sizeof(Handle));
    Discord_Initialize(AY_OBFUSCATE("1177501114942357575"), &Handle, 1, NULL);
}

void Discord::Update(const char* User, int dias_restantes) {
    static char detailsBuffer[128];
    static char stateBuffer[128];

    DiscordRichPresence discordPresence;
    memset(&discordPresence, 0, sizeof(discordPresence));

    sprintf_s(detailsBuffer, AY_OBFUSCATE("Usuario: %s"), User);
    sprintf_s(stateBuffer, AY_OBFUSCATE("Dias Restantes: %d"), dias_restantes);

    discordPresence.details = detailsBuffer;
    discordPresence.state = stateBuffer;
    discordPresence.startTimestamp = eptime;

    // Use uma key v�lida definida no Discord Developer Portal, n�o URL
    discordPresence.largeImageKey = AY_OBFUSCATE("iconi_menu");
    discordPresence.largeImageText = AY_OBFUSCATE("BlueStacks Version");

    Discord_UpdatePresence(&discordPresence);
}

void Discord::Shutdown() {
    Discord_ClearPresence();
}
