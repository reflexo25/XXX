#pragma once

namespace FWork {
    namespace Fonts {

        inline ImFont* FontAwesomeSolid = nullptr;
        inline ImFont* InterMedium = nullptr;
        inline ImFont* InterRegular = nullptr;
        inline ImFont* InterBold = nullptr;
        inline ImFont* InterSemiBold = nullptr;
        inline ImFont* FontChromeX = nullptr;
    }
}