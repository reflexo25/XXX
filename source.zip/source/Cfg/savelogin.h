#include <windows.h>
#include <fstream>
#include <string>
#include <cstring>
#include "../Imports/Scope.h"


std::string GetTempFilePath(const std::string& filename) {
    char tempPath[MAX_PATH];
    GetTempPathA(MAX_PATH, tempPath);
    return std::string(tempPath) + filename;
}


void SaveLogin() {
    std::string path = GetTempFilePath("LKAPI_data.txt");
    std::ofstream file(path, std::ios::out);
    if (file.is_open()) {
        file << Auth.Usuario << "\n";
        file << Auth.Senha << "\n";
        file.close();
    }
}


void LoadLogin() {
    std::string path = GetTempFilePath("LKAPI_data.txt");
    std::ifstream file(path, std::ios::in);
    if (file.is_open()) {
        std::string usuario, senha;
        if (std::getline(file, usuario) && std::getline(file, senha)) {
            strncpy_s(Auth.Usuario, sizeof(Auth.Usuario), usuario.c_str(), _TRUNCATE);
            Auth.Usuario[sizeof(Auth.Usuario) - 1] = '\0';
            strncpy_s(Auth.Senha, sizeof(Auth.Senha), senha.c_str(), _TRUNCATE);
            Auth.Senha[sizeof(Auth.Senha) - 1] = '\0';
        }
        file.close();
    }
    else {
        Auth.Usuario[0] = '\0';
        Auth.Senha[0] = '\0';
    }
}
