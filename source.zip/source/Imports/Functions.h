#pragma once

int TypeDefIndex(uintptr_t address) {
	uintptr_t inputPtr = Ler<uintptr_t>(address);
	if (inputPtr == 0) return false;
	int TypeDefIndex = Ler<int>(inputPtr + string2Offset(AY_OBFUSCATE("0x10")));
	return TypeDefIndex;
}

int PlayerNetwork = 8289;
int PlayerUGCCommon = 8347;
int Player_TrainingHumanTarget_Stand = 8219;
int Player_TrainingHumanTarget = 8218;
int NetworkAIPawn_AttackableEntity = 8151;