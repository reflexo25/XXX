#ifndef OFFSETS_H
#define OFFSETS_H

struct GameVarDef {
	uintptr_t GameVarPtr = string2Offset(AY_OBFUSCATE("0x94D9F20"));
};

struct {
	// --- [ GameVar ] --- //
	GameVarDef GameVarClass;

	// --- [ Access Class ] --- //
	uintptr_t GameEngine = string2Offset(AY_OBFUSCATE("0"));

	// --- [ Other ] --- // 
	uintptr_t jsonuni = string2Offset(AY_OBFUSCATE("0x5c"));

	// --- [ Player ] --- //
	uintptr_t EmVeiculo = string2Offset(AY_OBFUSCATE("0x280"));
	uintptr_t m_CachedTransform = string2Offset(AY_OBFUSCATE("0x34")); // TELEPORTAR PLAYER
	uintptr_t MainTransform = string2Offset(AY_OBFUSCATE("0x34")); 
	uintptr_t PRIDataPool = string2Offset(AY_OBFUSCATE("0x44"));
	uintptr_t MainCamTran = string2Offset(AY_OBFUSCATE("0x1AC")); 
	uintptr_t FollowCam = string2Offset(AY_OBFUSCATE("0x39C")); 
	uintptr_t HeadTransform = string2Offset(AY_OBFUSCATE("0x3A4")); 
	uintptr_t Inventario = string2Offset(AY_OBFUSCATE("0x3F4")); //	protected InventoryManager m_InventoryManager; // 0x3F4
	uintptr_t AvatarManager = string2Offset(AY_OBFUSCATE("0x408")); 
	uintptr_t isFiring = string2Offset(AY_OBFUSCATE("0x488"));
	uintptr_t PlayerNetwork_HHCBNAPCKHF = string2Offset(AY_OBFUSCATE("0x1344"));
	uintptr_t StatePlayer = string2Offset(AY_OBFUSCATE("0x78"));
	uintptr_t Inventario_Item = string2Offset(AY_OBFUSCATE("0x54"));//private Item m_itemOnHand; // 0x54

	// --- [ HP ] --- //
	uintptr_t ReplicationDataPoolUnsafe = string2Offset(AY_OBFUSCATE("0x8"));
	uintptr_t ReplicationDataUnsafe = string2Offset(AY_OBFUSCATE("0x10"));
	uintptr_t Health = string2Offset(AY_OBFUSCATE("0x10"));

	// --- [ UMAData ] --- //
	uintptr_t TeamMate = string2Offset(AY_OBFUSCATE("0x51"));

	// --- [ Avatar Manager ] --- //
	uintptr_t UmaAvatarSimple = string2Offset(AY_OBFUSCATE("0x94")); 

	// --- [ Uma Avatar Simple ] ---- //
	uintptr_t UMAData = string2Offset(AY_OBFUSCATE("0x10"));
	uintptr_t EstaVisivel = string2Offset(AY_OBFUSCATE("0x7C"));

	// --- [ GameEngine ] --- //
	uintptr_t BaseGame = string2Offset(AY_OBFUSCATE("0xC"));

	// --- [ BaseGame ] --- // 
	uintptr_t Partida = string2Offset(AY_OBFUSCATE("0x50"));

	// --- [ Partida ] --- //
	uintptr_t JogadorLocal = string2Offset(AY_OBFUSCATE("0x44"));

	// --- [ FollowCam ] ---- //
	uintptr_t Camera = string2Offset(AY_OBFUSCATE("0x14")); 

	// --- [ Camera ] ---- //
	uintptr_t Matrix = string2Offset(AY_OBFUSCATE("0xBC"));
	uintptr_t PlayerAttributes = 0x404; // TELEPORTAR PLAYER
	uintptr_t m_ShadowState = string2Offset(AY_OBFUSCATE("0x1344")); // TELEPORTAR PLAYER
	uintptr_t TargetPhysXPose = string2Offset(AY_OBFUSCATE("0x78")); // TELEPORTAR PLAYER
} Offsets;

#endif