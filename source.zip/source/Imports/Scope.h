﻿#pragma once

using namespace ImGui;

Discord* DiscordRPC;

struct {

	const char* Titulo = AY_OBFUSCATE("R E F L E X O");

	std::vector<const char*> Colluns = { "Main", "Visuals", "Misc" };

	bool OverlayView = true;
	bool AtivarFuncoes = true;

	bool Progress = false;
	bool Attached = false;

	bool Autenticado = false;

	char Usuario[256] = "";
	char Senha[256] = "";
	char HWID[256] = "";
	int dias_restantes = 0;
	std::string SessionToken;
	std::string LoaderHash = "abc123";
} Auth;



struct {

	int Menu = VK_INSERT;
	int GhostHack;
	int WallHack;
	int UnderCamEnabled;
	int TelekillToMe;
	int UpPlayer;
	int DownPlayer;
	int TeleportToEnemy;
	

} KeysBind;
bool Speed = false;
float SpeedVelocity = 3.25f;
bool DownPlayer = false;
bool SilentKill = false;
bool GhostHack = false;
bool LoginDisgraca = false;
bool FastSwitch = false;
bool Noscopeawp = false;
bool Aimlock2x = false;
bool Bloquearmira = false;
bool ESPNome = true;
bool ESPLinha = true;
bool ESPEsqueleto = true;
bool ESPCaixa = true;
bool ESPDistancia = true;
bool ESPVida = true;
bool WallHack = false;
bool UnderCamEnabled = false;
bool TelekillToMe = false;
bool UpPlayer = false;
bool TeleportToEnemy = false;
bool Silentdozinha = false;
bool trocarapida = false;

bool exibirPainel = false;
int PainelBind_Posicao = 0;



float espTextSize = 15.0f;
float espThickness = 1.5;
int linePosition = 1;
int AimbotType = 0;

float colorName[4] = {255.0f, 255.0f, 255.0f, 255.0f};
float colorLine[4] = { 255.0f, 255.0f, 255.0f, 255.0f };
float colorSkeleton[4] = { 255.0f, 255.0f, 255.0f, 255.0f };
float colorBox[4] = { 255.0f, 255.0f, 255.0f, 255.0f };
float colorDistance[4] = { 255.0f, 255.0f, 255.0f, 255.0f };
float colorDying[4] = { 255.0f, 0.0f, 0.0f, 255.0f };

float ParticleColour[4] = { 255.f, 255.f, 255.f, 255.f };
ImColor Particle = ImColor(0, 255, 200, 255);
int CurrentTab = 0;
int CurrentWindow = 0;
bool LoginMemory = false;
int LoginKey = VK_LBUTTON;
float LoginFov = 50.0f;
float DistanceMaxLogin = 130.0f;
bool ZeroLoginMort = true;
int DelayLogin = 500 + (rand() % 100);
constexpr int16_t KEY_PRESSED_MASK = 0x8000;
const uintptr_t LOGIN_OFF_READ = 0x3F0;
const uintptr_t LOGIN_OFF_WRITE = 0x50;