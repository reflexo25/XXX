#pragma once

uintptr_t il2cpp = 0x0;
uintptr_t anogs = 0x0;
uintptr_t libmain = 0x0;
int SWidth = 0;
int SHeight = 0;
HWND JanelaAlvo = NULL;

void GravarRegistroInt(const char* chave, int valor) {
    HKEY hKey;
    if (RegCreateKeyExA(HKEY_CURRENT_USER, AY_OBFUSCATE("Software\\LK"), 0, NULL, 0, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        RegSetValueExA(hKey, chave, 0, REG_DWORD, (const BYTE*)&valor, sizeof(valor));
        RegCloseKey(hKey);
    }
}

void LerRegistroInt(const char* chave, int& valor) {
    HKEY hKey;
    DWORD tamanho = sizeof(valor);
    if (RegOpenKeyExA(HKEY_CURRENT_USER, AY_OBFUSCATE("Software\\LK"), 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegQueryValueExA(hKey, chave, NULL, NULL, (BYTE*)&valor, &tamanho);
        RegCloseKey(hKey);
    }
}

HWND LookupWindowByClassName(const char* toFindClassName) {
    HWND result = NULL;

    auto enumCallback = [&](HWND currWnd) {

        char currClassName[260];

        if (RealGetWindowClassA(currWnd, currClassName, sizeof(currClassName)) < 1)
            return true;

        if (strcmp(currClassName, toFindClassName) == 0)
        {
            result = currWnd;
            return false;
        }

        return true;
        };

    std::function<bool(HWND)> callbackWrapper = enumCallback;

    EnumWindows([](HWND hwnd, LPARAM lParam) -> BOOL {
        auto callback = reinterpret_cast<std::function<bool(HWND)>*>(lParam);

        if ((*callback)(hwnd) == false)
            return FALSE;

        EnumChildWindows(hwnd, [](HWND childHwnd, LPARAM childLParam) -> BOOL {
            auto childCallback = reinterpret_cast<std::function<bool(HWND)>*>(childLParam);
            return (*childCallback)(childHwnd);
            }, lParam);

        return TRUE;
        }, reinterpret_cast<LPARAM>(&callbackWrapper));

    return result;
}

std::string ObterLocalDeInstalacao(DWORD pid) {
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    if (hProcess != NULL) {
        char buffer[MAX_PATH];
        DWORD dwSize = sizeof(buffer);
        if (QueryFullProcessImageNameA(hProcess, 0, buffer, &dwSize)) {
            PathRemoveFileSpec(buffer);
            CloseHandle(hProcess);
            return buffer;
        }
        CloseHandle(hProcess);
    }
    return "";
}

void ShellQuiet(const char* cmd) {
    static int x = 0;
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    if (CreateProcess(NULL, const_cast<char*>(cmd), NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {

        WaitForSingleObject(pi.hProcess, INFINITE);

        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
}

std::string Shell$$Return(const char* cmd) {
    HANDLE hReadPipe, hWritePipe;
    SECURITY_ATTRIBUTES saAttr{ sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };

    if (!CreatePipe(&hReadPipe, &hWritePipe, &saAttr, 0)) {
        return "";
    }

    STARTUPINFOA si{};
    si.cb = sizeof(si);
    si.hStdError = hWritePipe;
    si.hStdOutput = hWritePipe;
    si.dwFlags |= STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    PROCESS_INFORMATION pi{};
    std::string command = std::string("cmd.exe /C ") + cmd;

    BOOL success = CreateProcessA(
        NULL,
        const_cast<char*>(command.c_str()),
        NULL, NULL, TRUE,
        CREATE_NO_WINDOW,
        NULL, NULL,
        &si, &pi
    );

    CloseHandle(hWritePipe);

    std::string result;
    if (success) {
        char buffer[4096];
        DWORD bytesRead;

        while (ReadFile(hReadPipe, buffer, sizeof(buffer), &bytesRead, NULL) && bytesRead > 0) {
            result.append(buffer, bytesRead);
        }

        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }

    CloseHandle(hReadPipe);
    return result;
}


void ShellQuiet$$Adb(const char* cmd) {
    std::string AdbPath = ObterLocalDeInstalacao(_getpid());
    AdbPath += AY_OBFUSCATE("\\HD-Adb ");
    AdbPath += cmd;
    ShellQuiet(AdbPath.c_str());
}

std::string ShellReturn$$Adb(const char* cmd) {
    std::string AdbPath = ObterLocalDeInstalacao(_getpid());
    AdbPath = "\"" + AdbPath + "\\HD-Adb\" ";
    AdbPath += cmd;
    return Shell$$Return(AdbPath.c_str());
}


void ShellReturn$$HDPlayer(const char* cmd) {
    std::string AdbPath = ObterLocalDeInstalacao(_getpid());
    AdbPath += AY_OBFUSCATE("\\HD-Player ");
    AdbPath += cmd;
    ShellQuiet(AdbPath.c_str());
}

std::string DetectPortFromNetstat() {
    DWORD pid = _getpid();
    std::string cmd;
    cmd += AY_OBFUSCATE("cmd /c netstat -ano | findstr LISTENING");
    std::string output = Shell$$Return(cmd.c_str());
    if (output.empty()) return "";

    std::istringstream stream(output);
    std::string line;

    while (std::getline(stream, line)) {

        line = std::regex_replace(line, std::regex(AY_OBFUSCATE("^\\s+")), "");

        std::regex ws_re(AY_OBFUSCATE("\\s+"));
        std::vector<std::string> tokens(
            std::sregex_token_iterator(line.begin(), line.end(), ws_re, -1),
            std::sregex_token_iterator()
        );

        if (tokens.size() < 5)
            continue;

        std::string localAddr = tokens[1];
        std::string pidStr = tokens[4];

        if (pidStr != std::to_string(pid))
            continue;

        return localAddr;
    }

    return "";
}

enum class ABIType {
    Unknown,
    ARM32,
    ARM64,
    X86,
    X86_64
};

ABIType VMM_ABI = ABIType::Unknown;

const char* ABIToString(ABIType abi) {
    switch (abi) {
    case ABIType::ARM32: return "ARM32";
    case ABIType::ARM64: return "ARM64";
    case ABIType::X86: return "X86";
    case ABIType::X86_64: return "X86_64";
    default: return "Unknown";
    }
}

ABIType DetectABIFromAndroid() {
    std::string abiCmd = "-s " + DetectPortFromNetstat() + " shell getprop ro.product.cpu.abi";
    std::string abi = ShellReturn$$Adb(abiCmd.c_str());

    abi.erase(abi.find_last_not_of(" \n\r\t") + 1);

    if (abi == "x86_64") {
        std::cout << "[DetectABIFromAndroid] ABI detectado: x86_64\n";
        return ABIType::X86_64;
    }
    if (abi == "arm64-v8a") {
        std::cout << "[DetectABIFromAndroid] ABI detectado: arm64\n";
        return ABIType::ARM64;
    }
    if (abi == "x86") {
        std::cout << "[DetectABIFromAndroid] ABI detectado: x86\n";
        return ABIType::X86;
    }
    if (abi == "armeabi-v7a") {
        std::cout << "[DetectABIFromAndroid] ABI detectado: arm (v7a)\n";
        return ABIType::ARM32;
    }

    std::cout << "[DetectABIFromAndroid] ABI desconhecido: " << abi << "\n";
    return ABIType::Unknown;
}

bool ConnectEmulator() {
    static bool Conectado = false;
    if (!Conectado) {
        std::string conn_adb;
        conn_adb = AY_OBFUSCATE("connect ") + DetectPortFromNetstat().c_str();
        ShellQuiet$$Adb(conn_adb.c_str());

        std::string openGame_adb;
        openGame_adb += AY_OBFUSCATE("-s ") + DetectPortFromNetstat().c_str();
        openGame_adb += AY_OBFUSCATE(" shell monkey -p com.dts.freefireth -c android.intent.category.LAUNCHER 1");
        ShellQuiet$$Adb(openGame_adb.c_str());

        VMM_ABI = DetectABIFromAndroid();
        Conectado = true;
    }
    return Conectado;
}

uintptr_t ObterEnderecoDaBibliotecams(const char* libName, int tentativas = 10, int delayMs = 1000) {
    for (int i = 0; i < tentativas; i++) {

        std::string pid;
        pid += AY_OBFUSCATE("-s ") + DetectPortFromNetstat().c_str();
        pid += AY_OBFUSCATE(" shell pidof com.dts.freefireth");
        pid = ShellReturn$$Adb(pid.c_str());
        pid.erase(pid.find_last_not_of(" \n\r\t") + 1);

        char command[256];
        sprintf_s(command, AY_OBFUSCATE("-s %s shell /boot/android/android/system/xbin/bstk/su 0 busybox cat /proc/%s/maps"), DetectPortFromNetstat().c_str(), pid.c_str());

        std::string output = ShellReturn$$Adb(command);

        std::istringstream stream(output);
        std::string line;
        while (std::getline(stream, line)) {
            if (line.find(libName) != std::string::npos) {
                std::string baseAddress = line.substr(0, line.find('-'));
                uintptr_t addr = std::stoull(baseAddress, nullptr, 16);
                return addr;
            }
        }

        Sleep(delayMs);
    }
    return 0;
}


struct {
    void* pVM = NULL;
    uint64_t GuestCR3 = 0;
} VMM;

void* (*VMMGetCpuById)(void* pVM, int idCpu);
int (*PGMPhysRead)(void* pVM, uint32_t GCPhys, void* pvBuf, size_t bufSize);
int (*PGMPhysWrite)(void* pVM, uint32_t GCPhys, void* pvBuf, size_t bufSize);
uint64_t(*CPUMGetGuestCR3)(void* pVCpu);

int (*PGMPhysRead_Orig)(void* pVM, uint32_t GCPhys, void* pvBuf, size_t bufSize);
int PGMPhysReadHook(void* pVM, uint32_t GCPhys, void* pvBuf, size_t bufSize) {
    VMM.pVM = pVM;
    return PGMPhysRead_Orig(pVM, GCPhys, pvBuf, bufSize);
}

template<typename T>
T ReadPhysicalMemory(uintptr_t physicalAddress) {
    T var = 0;
    void* pVM = VMM.pVM;
    if (pVM != NULL) {
        int Read = PGMPhysRead(pVM, physicalAddress, &var, sizeof(T));
        if (Read == 0) {
            return var;
        }
    }
    return T();
}

bool PGMPhysRead64(uint64_t addr, uint64_t& value) {
    return PGMPhysRead(VMM.pVM, static_cast<uint32_t>(addr), &value, sizeof(uint64_t)) == 0;
}

uintptr_t EnderecoVirtualParaFisico64(uintptr_t guestVirtualAddr, uintptr_t guestCR3) {
    const uintptr_t PAGE_PRESENT = 1ULL;
    const uintptr_t PAGE_MASK = 0xFFFFFFFFF000ULL;
    const uintptr_t OFFSET_MASK = 0xFFFULL;

    uint16_t pml4Index = (guestVirtualAddr >> 39) & 0x1FF;
    uint16_t pdptIndex = (guestVirtualAddr >> 30) & 0x1FF;
    uint16_t pdIndex = (guestVirtualAddr >> 21) & 0x1FF;
    uint16_t ptIndex = (guestVirtualAddr >> 12) & 0x1FF;

    uint64_t entry = 0;
    uint64_t base = guestCR3 & PAGE_MASK;

    if (!PGMPhysRead64(base + pml4Index * 8, entry) || !(entry & PAGE_PRESENT))
        return 0;
    base = entry & PAGE_MASK;

    if (!PGMPhysRead64(base + pdptIndex * 8, entry) || !(entry & PAGE_PRESENT))
        return 0;
    base = entry & PAGE_MASK;

    if (!PGMPhysRead64(base + pdIndex * 8, entry) || !(entry & PAGE_PRESENT))
        return 0;
    base = entry & PAGE_MASK;

    if (!PGMPhysRead64(base + ptIndex * 8, entry) || !(entry & PAGE_PRESENT))
        return 0;

    return (entry & PAGE_MASK) + (guestVirtualAddr & OFFSET_MASK);
}


uintptr_t EnderecoVirtualParaFisico32(uint64_t guestCR3, uint32_t virtualAddr) {
    uint32_t pdeBase = guestCR3 & 0xFFFFF000;
    uint32_t pdeIndex = (virtualAddr >> 22) & 0x3FF;
    uint32_t pdeEntry = 0;

    if (PGMPhysRead(VMM.pVM, pdeBase + (pdeIndex * 4), &pdeEntry, sizeof(uint32_t)) == 0 && (pdeEntry & 0x1)) {
        uint32_t ptBase = pdeEntry & 0xFFFFF000;
        uint32_t ptIndex = (virtualAddr >> 12) & 0x3FF;
        uint32_t ptEntry = 0;

        if (PGMPhysRead(VMM.pVM, ptBase + (ptIndex * 4), &ptEntry, sizeof(uint32_t)) == 0 && (ptEntry & 0x1)) {
            return (ptEntry & 0xFFFFF000) + (virtualAddr % 0x1000);
        }
    }
    return 0;
}

uintptr_t TranslateVirtualToPhysical(uintptr_t va, uintptr_t cr3, uintptr_t& pa) {
    switch (VMM_ABI) {
    case ABIType::X86_64:
    case ABIType::ARM64: {
        pa = EnderecoVirtualParaFisico64(va, cr3);
        return pa;
    }

    case ABIType::X86:
    case ABIType::ARM32: {
        pa = EnderecoVirtualParaFisico32(cr3, static_cast<uint32_t>(va));
        return pa;
    }

    default:
        std::cout << "[TranslateVirtualToPhysical] ABI n�o suportado ou desconhecido.\n";
        return 0;
    }
}

void HookarLib(uintptr_t address, const std::vector<uint8_t>& expectedBytes) {
    while (true) {
        uint64_t physAddr = 0;
        if (TranslateVirtualToPhysical(address, VMM.GuestCR3, physAddr)) {
            PGMPhysWrite(VMM.pVM, static_cast<uint32_t>(physAddr),
                const_cast<uint8_t*>(expectedBytes.data()),
                expectedBytes.size());

            std::vector<uint8_t> actualBytes(expectedBytes.size());
            if (PGMPhysRead(VMM.pVM, static_cast<uint32_t>(physAddr),
                actualBytes.data(),
                actualBytes.size()) == 0) {

                if (std::equal(expectedBytes.begin(), expectedBytes.end(),
                    actualBytes.begin())) {
                    break;
                }
            }
        }
        Sleep(10);
    }
}

template<typename T>
T Ler(uint32_t virtualAddress) {
    T var{};
    void* pVM = VMM.pVM;
    if (pVM != nullptr && VMM.GuestCR3 != 0) {
        uint64_t  physAddr = 0;
        if (TranslateVirtualToPhysical(virtualAddress, VMM.GuestCR3, physAddr))
        {
            if (PGMPhysRead(pVM, static_cast<uint32_t>(physAddr), &var, sizeof(T)) == 0)
            {
                return var;
            }
        }
    }
    return T();
}

template<typename T>
void Escrever(uint32_t virtualAddress, T value) {
    void* pVM = VMM.pVM;
    if (pVM != nullptr && VMM.GuestCR3 != 0) {
        uint64_t  physAddr = 0;
        if (TranslateVirtualToPhysical(virtualAddress, VMM.GuestCR3, physAddr))
        {
            PGMPhysWrite(pVM, static_cast<uint32_t>(physAddr), &value, sizeof(T));
        }
    }
}

void LoadLibraryAndHook() {
    HMODULE BstkVMM = GetModuleHandleA(AY_OBFUSCATE("BstkVMM.dll"));
    if (BstkVMM != 0) {
        VMMGetCpuById = (void* (*)(void*, int))GetProcAddress(BstkVMM, static_cast<LPCSTR>(AY_OBFUSCATE("VMMGetCpuById")));
        PGMPhysRead = (int (*)(void*, uint32_t, void*, size_t))GetProcAddress(BstkVMM, static_cast<LPCSTR>(AY_OBFUSCATE("PGMPhysRead")));
        PGMPhysWrite = (int (*)(void*, uint32_t, void*, size_t))GetProcAddress(BstkVMM, static_cast<LPCSTR>(AY_OBFUSCATE("PGMPhysWrite")));
        CPUMGetGuestCR3 = (uint64_t(*)(void*))GetProcAddress(BstkVMM, static_cast<LPCSTR>(AY_OBFUSCATE("CPUMGetGuestCR3")));

        MH_Initialize();
        MH_CreateHook(PGMPhysRead, PGMPhysReadHook, (LPVOID*)&PGMPhysRead_Orig);
        MH_EnableHook(PGMPhysRead);

        while (VMM.GuestCR3 == 0)
        {
            if (il2cpp != 0 && VMM.pVM != nullptr)
            {
                void* cpuAddr = VMMGetCpuById(VMM.pVM, 0);
                if (cpuAddr != nullptr)
                {

                    uintptr_t GuestCR3 = CPUMGetGuestCR3(cpuAddr);
                    uint64_t  physAddr = 0;

                    if (TranslateVirtualToPhysical(il2cpp, GuestCR3, physAddr))
                    {
                        int ELFReader = 0;
                        if (PGMPhysRead(VMM.pVM, static_cast<uint32_t>(physAddr), &ELFReader, sizeof(ELFReader)) == 0)
                        {
                            if (ELFReader == string2Offset(AY_OBFUSCATE("0x464C457F")))
                            {
                                VMM.GuestCR3 = GuestCR3;
                            }
                        }
                    }
                }
            }
        }
    }
}