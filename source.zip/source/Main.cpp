﻿#define _CRT_SECURE_NO_WARNINGS
#include "Imports/includes.h"
#include "Auth.h"
#include "savelogin.h"
#include <cstdlib> // For rand() and srand()
#include <ctime>
#include <chrono>
#include <../Fonts/FontAwesome.hpp>
#include <../Fonts/FontAwesome6.hpp>


Vector3 GetViewDirection(UnityMatrix MatrixADDR) {
    Vector3 Out;
    float POS_X = MatrixADDR._14;
    float POS_Y = MatrixADDR._24;
    float POS_Z = MatrixADDR._34;
    float RT_Z = MatrixADDR._13;
    float UP_Z = MatrixADDR._23;
    float BK_Z = MatrixADDR._33;
    Out = Vector3(POS_X + RT_Z, POS_Y + UP_Z, POS_Z + BK_Z);
    return Out;
}

void Logar(const std::string& mensagem) {
    char desktopPath[MAX_PATH];
    SHGetFolderPathA(nullptr, CSIDL_DESKTOP, nullptr, 0, desktopPath);  

    std::ostringstream caminho;
    caminho << desktopPath << "\\log_debug.txt";

    std::ofstream logFile(caminho.str(), std::ios::app); 
    if (logFile.is_open()) {
        logFile << mensagem << std::endl;
        logFile.close();
    }
}

std::string int_to_hex(int i) {
    std::stringstream stream;
    stream << std::hex << i;
    return stream.str();
}

// TELEPORTAR PLAYER
struct EnemyData {
    uintptr_t address;
    bool isDying;
    short health;

};
static float savedPlayerY = 0.0f;
static bool playerSavedYWritten = false;
static auto lastResetTime = std::chrono::steady_clock::now();
static auto lastWriteTime = std::chrono::steady_clock::now();
auto ultimoTeleporte = std::chrono::steady_clock::now();
const int cooldownTeleporteMs = 1;
uintptr_t targetBloqueado = 0;
static float originalPlayerY = 0.0f;
static bool groundPositionSaved = false;
static bool playerYIsSaved = false;
void HandleTeleportToEnemy(uintptr_t localPlayer, uintptr_t targetEnemy) {
    if (!localPlayer || !targetEnemy) return;

    Vector3 enemyPos = GetPlayerPosition(targetEnemy, 0);

    uintptr_t enemyTransformComponent = Ler<uintptr_t>(targetEnemy + Offsets.m_CachedTransform);


    Vector3 enemyForward;
    if (!GetForward(enemyTransformComponent, enemyForward)) {

        return;
    }


    Vector3 newPlayerPos = enemyPos - (enemyForward * 1.0f);

    uintptr_t transform = Ler<uintptr_t>(localPlayer + string2Offset(AY_OBFUSCATE("0x34")));
    if (!transform) return;

    uintptr_t transformObjValue = Ler<uintptr_t>(transform + string2Offset(AY_OBFUSCATE("0x8")));
    if (!transformObjValue) return;

    uintptr_t indexValue = Ler<uintptr_t>(transformObjValue + string2Offset(AY_OBFUSCATE("0x24")));
    uintptr_t matrixValue = Ler<uintptr_t>(transformObjValue + string2Offset(AY_OBFUSCATE("0x20")));
    uintptr_t matrixListValue = Ler<uintptr_t>(matrixValue + string2Offset(AY_OBFUSCATE("0x10")));

    uintptr_t positionAddr = matrixListValue + (indexValue * 0x30);

    Escrever<Vector3>(positionAddr, newPlayerPos);
}
// TELEPORTAR PLAYER FIM



void DesenharESP(int width, int height) {

    SWidth = width;
    SHeight = height;

    if (Auth.AtivarFuncoes && Auth.Attached) {

        uintptr_t ClosestEnemy = 0;
        float DistanciaMaxima = 9999.9f;
        uintptr_t login_target = 0;
        float closest_aimbot_dist = FLT_MAX;
        static auto lastLoginActionTime = std::chrono::steady_clock::now();

        uintptr_t GameEngine = Ler<uintptr_t>(Ler<uintptr_t>(Ler<uintptr_t>(il2cpp + Offsets.GameEngine) + Offsets.jsonuni));
        if (GameEngine == 0) return;

        uintptr_t BaseGame = Ler<uintptr_t>(GameEngine + Offsets.BaseGame);
        if (BaseGame == 0) return;

        uintptr_t Partida = Ler<uintptr_t>(BaseGame + Offsets.Partida);
        if (Partida == 0) return;

        int MatchState = Ler<int>(Partida + string2Offset(AY_OBFUSCATE("0x3c")));
        if (MatchState != 1) return;
        
        uintptr_t JogadorLocal = Ler<uintptr_t>(Partida + Offsets.JogadorLocal);

        uintptr_t Arma = Ler<uintptr_t>(Ler<uintptr_t>(JogadorLocal + Offsets.Inventario) + Offsets.Inventario_Item);

        // TELEPORTAR PLAYER

        uintptr_t playerAttributes = Ler<uintptr_t>(JogadorLocal + Offsets.PlayerAttributes);

        bool alvoTravadoAindaValido = false;
        if (targetBloqueado != 0) {

            uintptr_t IPRIDataPool = Ler<uintptr_t>(targetBloqueado + Offsets.PRIDataPool);
            if (IPRIDataPool != 0) {
                uintptr_t ReplicationDataPoolUnsafe = Ler<uintptr_t>(IPRIDataPool + Offsets.ReplicationDataPoolUnsafe);
                if (ReplicationDataPoolUnsafe != 0) {
                    uintptr_t ReplicationDataUnsafe = Ler<uintptr_t>(ReplicationDataPoolUnsafe + Offsets.ReplicationDataUnsafe);
                    if (ReplicationDataUnsafe != 0) {
                        if (Ler<short>(ReplicationDataUnsafe + Offsets.Health) > 0) {
                            uintptr_t shadowState = Ler<uintptr_t>(targetBloqueado + Offsets.m_ShadowState);
                            bool isDying = false;
                            if (shadowState != 0) {
                                isDying = (Ler<int>(shadowState + Offsets.TargetPhysXPose) == 8);
                            }
                            if (!isDying) {
                                alvoTravadoAindaValido = true;
                            }
                        }
                    }
                }
            }
        }

   


        Vector3 MinhaPosicao = Transform$$ObterPosicao(Ler<uintptr_t>(JogadorLocal + Offsets.MainTransform));
        Vector3 MinhaPosicao_Camera = Transform$$ObterPosicao(Ler<uintptr_t>(JogadorLocal + Offsets.MainCamTran));
        Vector3 MinhaPosicao_Cabeca = GetHeadPosition(JogadorLocal);

        uintptr_t Camera_Ctr = Ler<uintptr_t>(BaseGame + 0x74);
        if (Camera_Ctr == 0) return;

        uintptr_t Camera = Ler<uintptr_t>(Camera_Ctr + string2Offset(AY_OBFUSCATE("0xC")));
        if (Camera == 0) return;

        uintptr_t IntPtrCam = Ler<uintptr_t>(Camera + string2Offset(AY_OBFUSCATE("0x8")));
        if (IntPtrCam == 0) return;

        UnityMatrix matrix = Ler<UnityMatrix>(IntPtrCam + Offsets.Matrix);

       
    
        static bool Pos = false;
        static bool IsGoingUp = true;
        static Vector3 LocalPosition = Vector3(0, 0, 0);
        static auto lastResetTime = std::chrono::steady_clock::now();
        static auto lastSwitchTime = std::chrono::steady_clock::now();

        if (DownPlayer) {
            if (!Pos) {
                Pos = true;
                LocalPosition = GetPlayerPosition(JogadorLocal, 0);
            }

            uintptr_t transform = Ler<uintptr_t>(JogadorLocal + string2Offset(AY_OBFUSCATE("0x34")));
            if (!transform) return;


            uintptr_t transformObjValue = Ler<uintptr_t>(transform + string2Offset(AY_OBFUSCATE("0x8")));
            if (!transformObjValue) return;


            uintptr_t indexValue = Ler<uintptr_t>(transformObjValue + string2Offset(AY_OBFUSCATE("0x24")));
            uintptr_t matrixValue = Ler<uintptr_t>(transformObjValue + string2Offset(AY_OBFUSCATE("0x20")));
            uintptr_t matrixListValue = Ler<uintptr_t>(matrixValue + string2Offset(AY_OBFUSCATE("0x10")));


            uintptr_t positionAddr = matrixListValue + (indexValue * 0x30);


            auto now = std::chrono::steady_clock::now();
            auto elapsedSwitch = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastSwitchTime).count();
            if (elapsedSwitch >= 500) {
                IsGoingUp = !IsGoingUp;
                lastSwitchTime = now;
            }


            float targetY = IsGoingUp ? LocalPosition.Y + 2.0f : LocalPosition.Y - 2.0f;


            Vector3 newPosition = Vector3(LocalPosition.X, targetY, LocalPosition.Z);


            Escrever<Vector3>(positionAddr, newPosition);
            lastResetTime = now;
        }
        else {
            auto now = std::chrono::steady_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastResetTime).count();
            if (elapsed >= 300) {
                Pos = false;
                IsGoingUp = true;
            }
        }

        static bool MyPosSaved = false;
        if (GhostHack) {
            bool Garota = Ler<bool>(JogadorLocal + string2Offset(AY_OBFUSCATE("0x6F1")));

            uintptr_t TransformHead;
            uintptr_t TransformChest;
            uintptr_t TransformStomach;
            uintptr_t TransformHip;
            uintptr_t TransformLeftShoulder;
            uintptr_t TransformLeftArm;
            uintptr_t TransformLeftForearm;
            uintptr_t TransformLeftHand;
            uintptr_t TransformRightShoulder;
            uintptr_t TransformRightArm;
            uintptr_t TransformRightForearm;
            uintptr_t TransformRightHand;
            uintptr_t TransformLeftThigh;
            uintptr_t TransformLeftShin;
            uintptr_t TransformLeftFoot;
            uintptr_t TransformRightFoot;
            uintptr_t TransformRightThigh;
            uintptr_t TransformRightShin;

            if (Garota) {
                TransformHead = string2Offset(AY_OBFUSCATE("0x3C")); //Cabeça
                TransformChest = string2Offset(AY_OBFUSCATE("0x18")); //Peito
                TransformStomach = string2Offset(AY_OBFUSCATE("0x14")); // Barriga
                TransformHip = string2Offset(AY_OBFUSCATE("0x10"));// Quadil

                TransformLeftShoulder = string2Offset(AY_OBFUSCATE("0x1C")); //OmbroEsquerdo
                TransformLeftArm = string2Offset(AY_OBFUSCATE("0x20")); //BraçoEsquerdo
                TransformLeftForearm = string2Offset(AY_OBFUSCATE("0x24")); //AntBraçoEsquerdo
                TransformLeftHand = string2Offset(AY_OBFUSCATE("0x28")); //MãoEsquerdo

                TransformRightShoulder = string2Offset(AY_OBFUSCATE("0x2C")); //OmbroDireito
                TransformRightArm = string2Offset(AY_OBFUSCATE("0x30")); //BraçoEsquerdo
                TransformRightForearm = string2Offset(AY_OBFUSCATE("0x34")); //AntBraçoDireito
                TransformRightHand = string2Offset(AY_OBFUSCATE("0x38")); //MãoDireito

                TransformLeftThigh = string2Offset(AY_OBFUSCATE("0x40")); //CoxaEsquerda
                TransformLeftShin = string2Offset(AY_OBFUSCATE("0x44")); //CanelaEsquerda
                TransformLeftFoot = string2Offset(AY_OBFUSCATE("0x48")); //PéEsquerdo

                TransformRightThigh = string2Offset(AY_OBFUSCATE("0x4C")); //CoxaDireito
                TransformRightShin = string2Offset(AY_OBFUSCATE("0x50")); //CanelaDireito
                TransformRightFoot = string2Offset(AY_OBFUSCATE("0x54")); //PéDireito
            }
            else {
                TransformHead = string2Offset(AY_OBFUSCATE("0x38")); //Cabeça
                TransformChest = string2Offset(AY_OBFUSCATE("0x14")); //Peito
                TransformStomach = string2Offset(AY_OBFUSCATE("0x10")); //Barriga
                TransformHip = string2Offset(AY_OBFUSCATE("0x48")); //Quadril

                TransformLeftShoulder = string2Offset(AY_OBFUSCATE("0x18")); //OmbroEsquerdo
                TransformLeftArm = string2Offset(AY_OBFUSCATE("0x1C")); //BraçoEsquerdo
                TransformLeftForearm = string2Offset(AY_OBFUSCATE("0x20")); //AntBraçoEsquerdo
                TransformLeftHand = string2Offset(AY_OBFUSCATE("0x24")); //MãoEsquerdo

                TransformRightShoulder = string2Offset(AY_OBFUSCATE("0x28")); //OmbroDireito
                TransformRightArm = string2Offset(AY_OBFUSCATE("0x2C")); //BraçoDireito
                TransformRightForearm = string2Offset(AY_OBFUSCATE("0x30")); //AntBraçoDireito
                TransformRightHand = string2Offset(AY_OBFUSCATE("0x34")); //MãoDireito

                TransformLeftThigh = string2Offset(AY_OBFUSCATE("0x3C")); //CoxaEsquerda
                TransformLeftShin = string2Offset(AY_OBFUSCATE("0x40")); //CanelaEsquerda
                TransformLeftFoot = string2Offset(AY_OBFUSCATE("0x44")); //PéEsquerdo

                TransformRightThigh = string2Offset(AY_OBFUSCATE("0x4C"));//CoxaDireito
                TransformRightShin = string2Offset(AY_OBFUSCATE("0x50"));//CanelaDireito
                TransformRightFoot = string2Offset(AY_OBFUSCATE("0x54"));//PéDireito
            }

            static Vector3 EnemyPositionHeadBoxVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationChestVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationStomachVEC3 = Vector3(0, 0, 0);

            static Vector3 LocationHipVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationLeftShoulderVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationLeftArmVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationLeftForearmVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationLeftHandVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationRightShoulderVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationRightArmVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationRightForearmVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationRightHandVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationLeftThighVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationLeftShinVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationLeftFootVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationRightThighVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationRightShinVEC3 = Vector3(0, 0, 0);
            static Vector3 LocationRightFootVEC3 = Vector3(0, 0, 0);

            if (!MyPosSaved) {
                MyPosSaved = true;
                EnemyPositionHeadBoxVEC3 = ObterOssos(JogadorLocal, TransformHead);
                LocationChestVEC3 = ObterOssos(JogadorLocal, TransformChest);
                LocationStomachVEC3 = ObterOssos(JogadorLocal, TransformStomach);

                LocationHipVEC3 = ObterOssos(JogadorLocal, TransformHip);
                LocationLeftShoulderVEC3 = ObterOssos(JogadorLocal, TransformLeftShoulder);
                LocationLeftArmVEC3 = ObterOssos(JogadorLocal, TransformLeftArm);
                LocationLeftForearmVEC3 = ObterOssos(JogadorLocal, TransformLeftForearm);

                LocationLeftHandVEC3 = ObterOssos(JogadorLocal, TransformLeftHand);
                LocationRightShoulderVEC3 = ObterOssos(JogadorLocal, TransformRightShoulder);
                LocationRightArmVEC3 = ObterOssos(JogadorLocal, TransformRightArm);

                LocationRightForearmVEC3 = ObterOssos(JogadorLocal, TransformRightForearm);
                LocationRightHandVEC3 = ObterOssos(JogadorLocal, TransformRightHand);
                LocationLeftThighVEC3 = ObterOssos(JogadorLocal, TransformLeftThigh);
                LocationLeftShinVEC3 = ObterOssos(JogadorLocal, TransformLeftShin);
                LocationLeftFootVEC3 = ObterOssos(JogadorLocal, TransformLeftFoot);
                LocationRightThighVEC3 = ObterOssos(JogadorLocal, TransformRightThigh);
                LocationRightShinVEC3 = ObterOssos(JogadorLocal, TransformRightThigh);
                LocationRightFootVEC3 = ObterOssos(JogadorLocal, TransformRightFoot);
            }

            Vector3 EnemyPositionHeadBox = World2Screen(matrix, EnemyPositionHeadBoxVEC3);
            Vector3 LocationChest = World2Screen(matrix, LocationChestVEC3);
            Vector3 LocationStomach = World2Screen(matrix, LocationStomachVEC3);
            Vector3 LocationHip = World2Screen(matrix, LocationHipVEC3);
            Vector3 LocationLeftShoulder = World2Screen(matrix, LocationLeftShoulderVEC3);
            Vector3 LocationLeftArm = World2Screen(matrix, LocationLeftArmVEC3);
            Vector3 LocationLeftForearm = World2Screen(matrix, LocationLeftForearmVEC3);

            Vector3 LocationLeftHand = World2Screen(matrix, LocationLeftHandVEC3);
            Vector3 LocationRightShoulder = World2Screen(matrix, LocationRightShoulderVEC3);
            Vector3 LocationRightArm = World2Screen(matrix, LocationRightArmVEC3);
            Vector3 LocationRightForearm = World2Screen(matrix, LocationRightForearmVEC3);
            Vector3 LocationRightHand = World2Screen(matrix, LocationRightHandVEC3);
            Vector3 LocationLeftThigh = World2Screen(matrix, LocationLeftThighVEC3);
            Vector3 LocationLeftShin = World2Screen(matrix, LocationLeftShinVEC3);
            Vector3 LocationLeftFoot = World2Screen(matrix, LocationLeftFootVEC3);
            Vector3 LocationRightThigh = World2Screen(matrix, LocationRightThighVEC3);
            Vector3 LocationRightShin = World2Screen(matrix, LocationRightShinVEC3);
            Vector3 LocationRightFoot = World2Screen(matrix, LocationRightFootVEC3);


            if (EnemyPositionHeadBox.Z == 0) {
                float r = 0.4588f, g = 0.1333f, b = 0.4549f;
                float thickness = 2.5f;

                DrawLine(EnemyPositionHeadBox.X, EnemyPositionHeadBox.Y, LocationChest.X, LocationChest.Y, thickness, r, g, b);
                DrawLine(LocationChest.X, LocationChest.Y, LocationStomach.X, LocationStomach.Y, thickness, r, g, b);
                DrawLine(LocationStomach.X, LocationStomach.Y, LocationHip.X, LocationHip.Y, thickness, r, g, b);

                DrawLine(LocationChest.X, LocationChest.Y, LocationLeftShoulder.X, LocationLeftShoulder.Y, thickness, r, g, b);
                DrawLine(LocationLeftShoulder.X, LocationLeftShoulder.Y, LocationLeftArm.X, LocationLeftArm.Y, thickness, r, g, b);
                DrawLine(LocationLeftArm.X, LocationLeftArm.Y, LocationLeftForearm.X, LocationLeftForearm.Y, thickness, r, g, b);
                DrawLine(LocationLeftForearm.X, LocationLeftForearm.Y, LocationLeftHand.X, LocationLeftHand.Y, thickness, r, g, b);

                DrawLine(LocationChest.X, LocationChest.Y, LocationRightShoulder.X, LocationRightShoulder.Y, thickness, r, g, b);
                DrawLine(LocationRightShoulder.X, LocationRightShoulder.Y, LocationRightArm.X, LocationRightArm.Y, thickness, r, g, b);
                DrawLine(LocationRightArm.X, LocationRightArm.Y, LocationRightForearm.X, LocationRightForearm.Y, thickness, r, g, b);
                DrawLine(LocationRightForearm.X, LocationRightForearm.Y, LocationRightHand.X, LocationRightHand.Y, thickness, r, g, b);

                DrawLine(LocationHip.X, LocationHip.Y, LocationLeftThigh.X, LocationLeftThigh.Y, thickness, r, g, b);
                DrawLine(LocationLeftThigh.X, LocationLeftThigh.Y, LocationLeftShin.X, LocationLeftShin.Y, thickness, r, g, b);
                DrawLine(LocationLeftShin.X, LocationLeftShin.Y, LocationLeftFoot.X, LocationLeftFoot.Y, thickness, r, g, b);

                DrawLine(LocationHip.X, LocationHip.Y, LocationRightThigh.X, LocationRightThigh.Y, thickness, r, g, b);
                DrawLine(LocationRightThigh.X, LocationRightThigh.Y, LocationRightShin.X, LocationRightShin.Y, thickness, r, g, b);
                DrawLine(LocationRightShin.X, LocationRightShin.Y, LocationRightFoot.X, LocationRightFoot.Y, thickness, r, g, b);
            }
        }
        else {
            MyPosSaved = false;
        }


        uint32_t List = Ler<uint32_t>(Partida + string2Offset(AY_OBFUSCATE("0xD8")));

        for (int i = 0; i < Ler<int>(List + string2Offset(AY_OBFUSCATE("0xC"))); i++) {

            uint32_t Entity = Ler<uint32_t>(Ler<uint32_t>(List + string2Offset(AY_OBFUSCATE("0x8"))) + string2Offset(AY_OBFUSCATE("0x10")) + string2Offset(AY_OBFUSCATE("0x4")) * i);
            if (Entity == 0) continue;

            int indexPlayer = TypeDefIndex(Entity);
            if (indexPlayer != PlayerNetwork && indexPlayer != PlayerUGCCommon && indexPlayer != Player_TrainingHumanTarget_Stand && indexPlayer != Player_TrainingHumanTarget) continue;

            uint32_t AvatarManager = Ler<uint32_t>(Entity + Offsets.AvatarManager);
            if (AvatarManager == 0) continue;

            uint32_t UmaAvatarSimple = Ler<uint32_t>(AvatarManager + Offsets.UmaAvatarSimple);
            if (UmaAvatarSimple == 0) continue;

            uint32_t UmaData = Ler<uint32_t>(UmaAvatarSimple + Offsets.UMAData);
            if (UmaData == 0) continue;

            int EntityProperties = Ler<int>(Entity + string2Offset(AY_OBFUSCATE("0xB28")));
            if (EntityProperties == 0) {
                bool IsVisible = Ler<bool>(UmaAvatarSimple + 0x7C);
                if (!IsVisible) continue;
            }

            uint32_t IPRIDataPool = Ler<uint32_t>(Entity + Offsets.PRIDataPool);
            if (IPRIDataPool == 0) continue;

            uint32_t ReplicationDataPoolUnsafe = Ler<uint32_t>(IPRIDataPool + Offsets.ReplicationDataPoolUnsafe);
            if (ReplicationDataPoolUnsafe == 0) continue;

            uint32_t ReplicationDataUnsafe = Ler<uint32_t>(ReplicationDataPoolUnsafe + Offsets.ReplicationDataUnsafe);
            if (ReplicationDataUnsafe == 0) continue;

            short Health = Ler<short>(ReplicationDataUnsafe + Offsets.Health);
            if (Health <= 0) continue;

            bool isDying = false;
            uint32_t m_IsKnockStatus = Ler<uint32_t>(Entity + Offsets.PlayerNetwork_HHCBNAPCKHF);
            if (m_IsKnockStatus != 0) {
                int enemyStatus = Ler<int>(m_IsKnockStatus + Offsets.StatePlayer);
                isDying = (enemyStatus == 8);
            }

            static Vector3 PlayerPos;


            if (LoginMemory) {
                bool isKnockedForAimbot = isDying;

                if (ZeroLoginMort && isKnockedForAimbot) {

                }
                else {
                    Vector3 head_pos_3d = GetHeadPosition(Entity);
                    float distance_3d = Vector3::Distance(PlayerPos, head_pos_3d);

                    if (distance_3d <= DistanceMaxLogin) {
                        Vector3 head_pos_2d_vec = World2Screen(matrix, head_pos_3d);
                        if (head_pos_2d_vec.Z == 0) {
                            Vector2 screen_center = { (float)SWidth / 2.0f, (float)SHeight / 2.0f };
                            Vector2 head_pos_2d = { head_pos_2d_vec.X, head_pos_2d_vec.Y };
                            float crosshair_dist = Vector2::Distance(screen_center, head_pos_2d);

                            if (crosshair_dist <= LoginFov && crosshair_dist < closest_aimbot_dist) {
                                closest_aimbot_dist = crosshair_dist;
                                login_target = Entity;
                            }
                        }
                    }
                }
            }

            uint32_t localPlayer = Entity;
            bool isLocalPlayer = Ler<bool>(UmaData + string2Offset(AY_OBFUSCATE("0x50")));

            if (isLocalPlayer == 1) {
                PlayerPos = GetPlayerPosition(localPlayer, 0);
            }
            else {
                uint32_t FNCMBMMKLLI_BGGJJKKKFDC = Ler<uint32_t>(Partida + string2Offset(AY_OBFUSCATE("0x64")));
                if (FNCMBMMKLLI_BGGJJKKKFDC != 0) {
                    localPlayer = Ler<uint32_t>(FNCMBMMKLLI_BGGJJKKKFDC + string2Offset(AY_OBFUSCATE("0x28")));
                    if (Entity == localPlayer) {
                        PlayerPos = GetPlayerPosition(localPlayer, 0);
                    }
                }
            }

            if (isLocalPlayer == 1) continue;

            bool isTeam = Ler<bool>(UmaData + Offsets.TeamMate);
            if (isTeam) continue;

            bool Garota = Ler<bool>(Entity + string2Offset(AY_OBFUSCATE("0x6F1")));

            uint32_t TransformHead = Garota ? string2Offset(AY_OBFUSCATE("0x3C")) : string2Offset(AY_OBFUSCATE("0x38"));
            uint32_t TransformChest = string2Offset(AY_OBFUSCATE("0x14"));
            uint32_t TransformStomach = string2Offset(AY_OBFUSCATE("0x10"));
            uint32_t TransformHip = Garota ? string2Offset(AY_OBFUSCATE("0x10")) : string2Offset(AY_OBFUSCATE("0x48"));

            uint32_t TransformLeftShoulder = Garota ? string2Offset(AY_OBFUSCATE("0x1C")) : string2Offset(AY_OBFUSCATE("0x18"));
            uint32_t TransformLeftArm = Garota ? string2Offset(AY_OBFUSCATE("0x20")) : string2Offset(AY_OBFUSCATE("0x1C"));
            uint32_t TransformLeftForearm = Garota ? string2Offset(AY_OBFUSCATE("0x24")) : string2Offset(AY_OBFUSCATE("0x20"));
            uint32_t TransformLeftHand = Garota ? string2Offset(AY_OBFUSCATE("0x28")) : string2Offset(AY_OBFUSCATE("0x24"));

            uint32_t TransformRightShoulder = Garota ? string2Offset(AY_OBFUSCATE("0x2C")) : string2Offset(AY_OBFUSCATE("0x28"));
            uint32_t TransformRightArm = Garota ? string2Offset(AY_OBFUSCATE("0x30")) : string2Offset(AY_OBFUSCATE("0x2C"));
            uint32_t TransformRightForearm = Garota ? string2Offset(AY_OBFUSCATE("0x34")) : string2Offset(AY_OBFUSCATE("0x30"));
            uint32_t TransformRightHand = Garota ? string2Offset(AY_OBFUSCATE("0x38")) : string2Offset(AY_OBFUSCATE("0x34"));

            uint32_t TransformLeftThigh = Garota ? string2Offset(AY_OBFUSCATE("0x40")) : string2Offset(AY_OBFUSCATE("0x3C"));
            uint32_t TransformLeftShin = string2Offset(AY_OBFUSCATE("0x40"));
            uint32_t TransformLeftFoot = Garota ? string2Offset(AY_OBFUSCATE("0x48")) : string2Offset(AY_OBFUSCATE("0x44"));

            uint32_t TransformRightThigh = string2Offset(AY_OBFUSCATE("0x4C"));
            uint32_t TransformRightShin = string2Offset(AY_OBFUSCATE("0x50"));
            uint32_t TransformRightFoot = string2Offset(AY_OBFUSCATE("0x54"));

            uint32_t CapsuleCollider = Ler<uint32_t>(Ler<uint32_t>(Entity + string2Offset(AY_OBFUSCATE("0x688"))) + string2Offset(AY_OBFUSCATE("0x8"))); 

            auto CapsuleCollider$$Head = World2Screen(matrix, ObterOssos(Entity, TransformHead));
            auto CapsuleCollider$$Chest = World2Screen(matrix, ObterOssos(Entity, TransformChest));
            auto CapsuleCollider$$Stomach = World2Screen(matrix, ObterOssos(Entity, TransformStomach));
            auto CapsuleCollider$$Hip = World2Screen(matrix, ObterOssos(Entity, TransformHip));

            auto CapsuleCollider$$LeftShoulder = World2Screen(matrix, ObterOssos(Entity, TransformLeftShoulder));
            auto CapsuleCollider$$LeftArm = World2Screen(matrix, ObterOssos(Entity, TransformLeftArm));
            auto CapsuleCollider$$LeftForearm = World2Screen(matrix, ObterOssos(Entity, TransformLeftForearm));
            auto CapsuleCollider$$LeftHand = World2Screen(matrix, ObterOssos(Entity, TransformLeftHand));

            auto CapsuleCollider$$RightShoulder = World2Screen(matrix, ObterOssos(Entity, TransformRightShoulder));
            auto CapsuleCollider$$RightArm = World2Screen(matrix, ObterOssos(Entity, TransformRightArm));
            auto CapsuleCollider$$RightForearm = World2Screen(matrix, ObterOssos(Entity, TransformRightForearm));
            auto CapsuleCollider$$RightHand = World2Screen(matrix, ObterOssos(Entity, TransformRightHand));

            auto CapsuleCollider$$LeftThigh = World2Screen(matrix, ObterOssos(Entity, TransformLeftThigh));
            auto CapsuleCollider$$LeftShin = World2Screen(matrix, ObterOssos(Entity, TransformLeftShin));
            auto CapsuleCollider$$LeftFoot = World2Screen(matrix, ObterOssos(Entity, TransformLeftFoot));

            auto CapsuleCollider$$RightThigh = World2Screen(matrix, ObterOssos(Entity, TransformRightThigh));
            auto CapsuleCollider$$RightShin = World2Screen(matrix, ObterOssos(Entity, TransformRightShin));
            auto CapsuleCollider$$RightFoot = World2Screen(matrix, ObterOssos(Entity, TransformRightFoot));

            Vector3 EnemyHeadPos = GetHeadPosition(Entity);
            Vector3 EnemyPos = GetPlayerPosition(Entity, 0);

            Vector3 WorldEnemyPos = World2Screen(matrix, EnemyPos + (Vector3::Down() * 0.1f));
            Vector3 WorldEnemyHeadPos = World2Screen(matrix, EnemyHeadPos + (Vector3::Up() * 0.20f));

            float Distance = Vector3::Distance(EnemyPos, PlayerPos);

            Vector3 PosInScr = World2Screen(matrix, EnemyPos + (Vector3::Down() * 0.1) + Vector3::Zero());
            Vector3 PosHeadInScr = World2Screen(matrix, EnemyHeadPos + (Vector3::Up() * 0.20) + Vector3::Zero());
            float Y = (SWidth / 4.0) / Distance;
            PosHeadInScr.Y = PosHeadInScr.Y - Y + (SWidth / 4.0) / Distance;
            Vector2 v2Middle = Vector2((float)(SWidth / 2), (float)(SHeight / 2));
            Vector2 v2Loc = Vector2(PosHeadInScr.X, PosHeadInScr.Y);

            float DistanciaNaTela = Vector2::Distance(v2Middle, v2Loc);

            if (TelekillToMe) {
                if (!isDying) {
                    if (Distance <= 8.0f) {
                        if (Distance <= DistanciaMaxima) {
                            DistanciaMaxima = Distance;
                            ClosestEnemy = Entity;
                        }
                    }
                    else {
                        if (isInsideFov((int)PosHeadInScr.X, (int)PosHeadInScr.Y)) {
                            if (DistanciaNaTela <= DistanciaMaxima) {
                                DistanciaMaxima = DistanciaNaTela;
                                ClosestEnemy = Entity;
                            }
                        }
                    }
                }
            }
            else {
                if (isInsideFov((int)PosHeadInScr.X, (int)PosHeadInScr.Y)) {
                    if (!isDying) {
                        if (DistanciaNaTela <= DistanciaMaxima) {
                            DistanciaMaxima = DistanciaNaTela;
                            ClosestEnemy = Entity;
                        }
                    }
                }
            }

            if (WorldEnemyPos.Z != 0 || WorldEnemyHeadPos.Z != 0) continue;

            float Height = (WorldEnemyPos.Y) - WorldEnemyHeadPos.Y;
            float Width = Height * 0.55f;

            Rect PlayerRect(WorldEnemyHeadPos.X - (Width / 2), WorldEnemyHeadPos.Y, Width, Height);

            setlocale(LC_NUMERIC, "C");
            wchar_t buffer[30];
            swprintf(buffer, 30, AY_OBFUSCATE(L"%.2fm"), Distance);
            setlocale(LC_NUMERIC, "");

            if (ESPNome) {
                std::string nameStr;
                const char* name = AY_OBFUSCATE("BOT");
                auto BaseProfileInfo = Ler<uint32_t>(Entity + string2Offset(AY_OBFUSCATE("0x1350")));
                if (BaseProfileInfo != 0) {
                    auto PlayerName = Ler<uint32_t>(BaseProfileInfo + string2Offset(AY_OBFUSCATE("0x18")));
                    if (PlayerName != 0) {
                        auto getNameField = PlayerName + string2Offset(AY_OBFUSCATE("0xC"));
                        int getNameCount = Ler<int>(PlayerName + string2Offset(AY_OBFUSCATE("0x8")));
                        nameStr = ObterStr(getNameField, getNameCount);
                        name = nameStr.c_str();
                    }
                }
                ImVec4 color = isDying ? ImVec4(colorDying[0], colorDying[1], colorDying[2], colorDying[3]) : ImVec4(colorName[0], colorName[1], colorName[2], colorName[3]);
                DrawName(name, espTextSize, Vector2(WorldEnemyHeadPos.X, WorldEnemyHeadPos.Y - 1.0f), color.x, color.y, color.z);
            }

            if (ESPLinha) {
                ImVec4 color = isDying ? ImVec4(colorDying[0], colorDying[1], colorDying[2], colorDying[3]) : ImVec4(colorLine[0], colorLine[1], colorLine[2], colorLine[3]);
                if (linePosition == 1)
                    DrawLine(width / 2, height, WorldEnemyHeadPos.X, WorldEnemyHeadPos.Y + Height + (ESPDistancia ? espTextSize + 2 : 1), espThickness, color.x, color.y, color.z);
                if (linePosition == 0)
                    DrawLine(width / 2, 0, WorldEnemyHeadPos.X, WorldEnemyHeadPos.Y - (ESPNome ? espTextSize + 2 : 1), espThickness, color.x, color.y, color.z);
            }

            if (ESPCaixa) {
                ImVec4 color = isDying ? ImVec4(colorDying[0], colorDying[1], colorDying[2], colorDying[3]) : ImVec4(colorBox[0], colorBox[1], colorBox[2], colorBox[3]);
                DrawBox(PlayerRect, espThickness, color.x, color.y, color.z);
            }

            if (ESPEsqueleto) {
                ImVec4 color = isDying ? ImVec4(colorDying[0], colorDying[1], colorDying[2], colorDying[3]) : ImVec4(colorSkeleton[0], colorSkeleton[1], colorSkeleton[2], colorSkeleton[3]);
                DrawLine(CapsuleCollider$$Head.X, CapsuleCollider$$Head.Y, CapsuleCollider$$Chest.X, CapsuleCollider$$Chest.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$Chest.X, CapsuleCollider$$Chest.Y, CapsuleCollider$$Stomach.X, CapsuleCollider$$Stomach.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$Stomach.X, CapsuleCollider$$Stomach.Y, CapsuleCollider$$Hip.X, CapsuleCollider$$Hip.Y, espThickness, color.x, color.y, color.z);

                DrawLine(CapsuleCollider$$Chest.X, CapsuleCollider$$Chest.Y, CapsuleCollider$$LeftShoulder.X, CapsuleCollider$$LeftShoulder.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$LeftShoulder.X, CapsuleCollider$$LeftShoulder.Y, CapsuleCollider$$LeftArm.X, CapsuleCollider$$LeftArm.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$LeftArm.X, CapsuleCollider$$LeftArm.Y, CapsuleCollider$$LeftForearm.X, CapsuleCollider$$LeftForearm.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$LeftForearm.X, CapsuleCollider$$LeftForearm.Y, CapsuleCollider$$LeftHand.X, CapsuleCollider$$LeftHand.Y, espThickness, color.x, color.y, color.z);

                DrawLine(CapsuleCollider$$Chest.X, CapsuleCollider$$Chest.Y, CapsuleCollider$$RightShoulder.X, CapsuleCollider$$RightShoulder.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$RightShoulder.X, CapsuleCollider$$RightShoulder.Y, CapsuleCollider$$RightArm.X, CapsuleCollider$$RightArm.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$RightArm.X, CapsuleCollider$$RightArm.Y, CapsuleCollider$$RightForearm.X, CapsuleCollider$$RightForearm.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$RightForearm.X, CapsuleCollider$$RightForearm.Y, CapsuleCollider$$RightHand.X, CapsuleCollider$$RightHand.Y, espThickness, color.x, color.y, color.z);

                DrawLine(CapsuleCollider$$Hip.X, CapsuleCollider$$Hip.Y, CapsuleCollider$$LeftThigh.X, CapsuleCollider$$LeftThigh.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$LeftThigh.X, CapsuleCollider$$LeftThigh.Y, CapsuleCollider$$LeftShin.X, CapsuleCollider$$LeftShin.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$LeftShin.X, CapsuleCollider$$LeftShin.Y, CapsuleCollider$$LeftFoot.X, CapsuleCollider$$LeftFoot.Y, espThickness, color.x, color.y, color.z);

                DrawLine(CapsuleCollider$$Hip.X, CapsuleCollider$$Hip.Y, CapsuleCollider$$RightThigh.X, CapsuleCollider$$RightThigh.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$RightThigh.X, CapsuleCollider$$RightThigh.Y, CapsuleCollider$$RightShin.X, CapsuleCollider$$RightShin.Y, espThickness, color.x, color.y, color.z);
                DrawLine(CapsuleCollider$$RightShin.X, CapsuleCollider$$RightShin.Y, CapsuleCollider$$RightFoot.X, CapsuleCollider$$RightFoot.Y, espThickness, color.x, color.y, color.z);
            }

            if (ESPDistancia) {
                ImVec4 color = isDying ? ImVec4(colorDying[0], colorDying[1], colorDying[2], colorDying[3]) : ImVec4(colorDistance[0], colorDistance[1], colorDistance[2], colorDistance[3]);
                DrawDistance(buffer, espTextSize, Vector2(PlayerRect.x + (PlayerRect.width / 2), PlayerRect.y + PlayerRect.height + 1.0f), color.x, color.y, color.z);
            }

            if (ESPVida) {
                DrawRoundHealthBar(PlayerRect, 200, Health);
            }
        }
        // AIMBOT COLLIDER

        if (LoginMemory) {
            try {
                uintptr_t headColliderAddr = login_target + LOGIN_OFF_READ;
                uint32_t headCollider = Ler<uint32_t>(headColliderAddr);

                // Verifica se já está travado nesse valor
                uint32_t currentValue = Ler<uint32_t>(login_target + LOGIN_OFF_WRITE);
                if (currentValue != headCollider) {
                    Escrever<uint32_t>(login_target + LOGIN_OFF_WRITE, headCollider);
                }
            }
            catch (const std::exception& e) {
                std::cerr << "Erro ao acessar memória: " << e.what() << std::endl;
            }
            catch (...) {
                std::cerr << "Erro desconhecido ao acessar memória" << std::endl;
            }
        }





























    }
}

DWORD WINAPI ThreadOverlay() {
    DirectOverlaySetOption(D2DOV_FONT_ARIAL);
    DirectOverlaySetup(DesenharESP, JanelaAlvo);
}

static inline ImVec2 Size = ImVec2(640, 460);

void MouseMovement() {
    if (ImGui::IsItemActive()) {
        static RECT Rect = { 0 };
        GetWindowRect(hwnd, &Rect);
        ImGui::GetWindowSize();
        MoveWindow(hwnd, Rect.left + ImGui::GetMouseDragDelta().x, Rect.top + ImGui::GetMouseDragDelta().y, Size.x, Size.y, TRUE);
    }
}

void Run_RenderGUI() {

    eventPoll();
    ImGui::GetStyle().Colors[ImGuiCol_CheckMark] = ImVec4(0.4f, 0.6f, 1.0f, 1.0f);
    ImGui::GetIO().MouseDrawCursor = Auth.OverlayView;
    if (Twidht != 0 && Theight != 0) {
        CleanupRenderTarget();
        g_pSwapChain->ResizeBuffers(0, Twidht, Theight, DXGI_FORMAT_UNKNOWN, 0);
        Theight = Twidht = 0;
        CreateRenderTarget();
    }

    WndRECT TargetWindowRect;
    GetClientRect(hTargetWindow, &TargetWindowRect);
    MapWindowPoints(hTargetWindow, nullptr, reinterpret_cast<LPPOINT>(&TargetWindowRect), 2);
    MoveWindow(hwnd, TargetWindowRect.left, TargetWindowRect.top, TargetWindowRect.Width(), TargetWindowRect.Height(), false);

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    // PAINEL DE BIND 
    float larguraPainel = 200.0f;
    float alturaCabecalho = 35.0f;
    float raioBorda = 8.0f;
    float margem = 12.0f;

    ImU32 corCabecalho = IM_COL32(30, 30, 30, 255); 
    ImU32 corFundo = IM_COL32(20, 20, 20, 255);    
    ImU32 corBorda = IM_COL32(80, 80, 80, 255);    
    ImU32 corTitulo = IM_COL32(255, 255, 255, 255);
    ImU32 corLinhaRoxa = IM_COL32(147, 51, 234, 255);
    ImU32 corAtivo = IM_COL32(34, 197, 94, 255);
    ImU32 corInativo = IM_COL32(120, 120, 120, 255); 

     std::vector<std::pair<std::string, ImU32>> listaStatus;


   /* listaStatus.push_back({
        "UpPlayer: " + std::string(UpPlayer ? "On" : "Off"),
        UpPlayer ? corAtivo : corInativo
        });/*


   /*listaStatus.push_back({
        "Puxar Player: " + std::string(TelekillToMe ? "On" : "Off"),
        TelekillToMe ? corAtivo : corInativo
        });


    listaStatus.push_back({
       "Camera Direita: " + std::string(UnderCamEnabled ? "On" : "Off"),
        UnderCamEnabled ? corAtivo : corInativo
        });*/


        /*listaStatus.push_back({
        "GhostHack: " + std::string(GhostHack ? "On" : "Off"),
        GhostHack ? corAtivo : corInativo
        });/*


   
    /* listaStatus.push_back({
        "Parkour Player: " + std::string(DownPlayer ? "On" : "Off"),
        DownPlayer ? corAtivo : corInativo
        });*/

    listaStatus.push_back({
        "Aimbot: " + std::string(LoginMemory ? "ON" : "OFF"),
        LoginMemory ? corAtivo : corInativo
        });

    float alturaTexto = listaStatus.size() * 24.0f;
    float alturaPainel = alturaCabecalho + (listaStatus.empty() ? 0 : alturaTexto + 15.0f);

    ImVec2 posicao;

    switch (PainelBind_Posicao) {
    case 0: // Topo-Esquerda
        posicao = ImVec2(TargetWindowRect.Width() - larguraPainel - 5.0f, (TargetWindowRect.Height() - alturaPainel) / 2.0f);
        break;
    }

    if (exibirPainel) {
        ImGui::GetForegroundDrawList()->AddRectFilled(
            posicao,
            ImVec2(posicao.x + larguraPainel, posicao.y + alturaPainel),
            corFundo,
            raioBorda
        );
        ImGui::GetForegroundDrawList()->AddRectFilled(
            posicao,
            ImVec2(posicao.x + larguraPainel, posicao.y + alturaCabecalho),
            corCabecalho,
            raioBorda,
            ImDrawFlags_RoundCornersTop
        );
        ImGui::GetForegroundDrawList()->AddRect(
            posicao,
            ImVec2(posicao.x + larguraPainel, posicao.y + alturaPainel),
            corBorda,
            raioBorda,
            0,
            1.0f
        );

        ImGui::PushFont(FontAwesomeSolid);
        ImVec2 tamanhoIcone = ImGui::CalcTextSize(ICON_FA_KEYBOARD);
        ImVec2 posicaoIcone = ImVec2(posicao.x + margem, posicao.y + (alturaCabecalho - tamanhoIcone.y) / 2);
        ImGui::GetForegroundDrawList()->AddText(posicaoIcone, corTitulo, ICON_FA_KEYBOARD);
        ImGui::PopFont();

        ImGui::PushFont(LexendRegular);
        ImGui::GetForegroundDrawList()->AddText(
            ImVec2(posicaoIcone.x + tamanhoIcone.x + 8.0f, posicao.y + (alturaCabecalho - ImGui::GetFontSize()) / 2),
            corTitulo,
            "BINDS"
        );
        ImGui::PopFont();

        float linhaY = posicao.y + alturaCabecalho - 1.0f;
        ImGui::GetForegroundDrawList()->AddLine(
            ImVec2(posicao.x, linhaY),
            ImVec2(posicao.x + larguraPainel, linhaY),
            corLinhaRoxa,
            1.5f
        );

        if (!listaStatus.empty()) {
            ImGui::PushFont(LexendRegular);
            float atualY = posicao.y + alturaCabecalho + 12.0f;
            for (const auto& status : listaStatus) {
                ImGui::GetForegroundDrawList()->AddText(
                    ImVec2(posicao.x + margem, atualY),
                    status.second,
                    status.first.c_str()
                );
                atualY += 24.0f;
            }
            ImGui::PopFont();
        }
    }

    if (Auth.OverlayView) {
        static float AnimaTab = 0.0f;
        static int LastCurrentTab = 0;

        if (LastCurrentTab != CurrentTab) {
            AnimaTab = (LastCurrentTab > CurrentTab) ? -460.f : 460.f;
            LastCurrentTab = CurrentTab;
        }

        AnimaTab = ImLerp(AnimaTab, 0.f, 6.f * ImGui::GetIO().DeltaTime);

        static int LastCurrentSub = 0;
        static int CurrentSub = 0;
        static float Anima = 0.f;

        if (LastCurrentSub != CurrentSub) {
            Anima = (LastCurrentSub > CurrentSub) ? -460.f : 460.f;
            LastCurrentSub = CurrentSub;
        }

        Anima = ImLerp(Anima, 0.f, 6.f * ImGui::GetIO().DeltaTime);

        NotificationManager::DesenharNotificacoes();
        if (CurrentWindow == 0) {
            ImGui::SetNextWindowSize(ImVec2(545, 400));
            ImGui::Begin(" NO XIT -- NO SHINE", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoScrollWithMouse);
            {
                ImDrawList* DrawList = ImGui::GetWindowDrawList();
                ImVec2 Pos = ImGui::GetWindowPos();
                ImVec2 Size = ImGui::GetWindowSize();

                ImVec2 textSize = ImGui::CalcTextSize(" NO XIT -- NO SHINE");
                ImVec2 textPos = Pos + ImVec2(Pos.x + 8.0f - Pos.x, (Size.y * 0.2f - 40.0f - textSize.y) * 0.5f + 0.3f);
                DrawList->AddRectFilled(Pos, Pos + ImVec2(Size.x, Size.y * 0.2f - 40.0f), ImGui::GetColorU32(ImGuiCol_TitleBg), ImGui::GetStyle().WindowRounding, ImDrawFlags_RoundCornersTop);
                DrawList->AddText(textPos, ImGui::GetColorU32(ImGuiCol_Text), " NO XIT -- NO SHINE");

                MouseMovement();
                ImVec2 childInnerSize = ImGui::GetWindowSize();
                float centerX = (childInnerSize.x - 285) * 0.5f;
                float centerY = (childInnerSize.y - 180) * 0.5f + 55;
                ImVec2 childPosScreen = ImGui::GetCursorScreenPos();

                float childWidth = Size.x - (Size.x / 3.5f);
                ImGui::SetCursorPos(ImVec2((Size.x - childWidth) * 0.5f, AnimaTab));
                ImGui::BeginChild("LoginChild", ImVec2(childWidth, Size.y), ImGuiChildFlags_None, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
                ImGui::SetCursorPos(ImVec2((childWidth - 360.0f) * 0.5f + 50.0f, 110));
                ImGui::BeginGroup();
                {
                    if (CurrentTab == 0) {
                        ImGui::Text("Username");
                        ImGui::InputTextEx3(ICON_FA_USER, nullptr, Auth.Usuario, IM_ARRAYSIZE(Auth.Usuario), ImVec2(285, 35), ImGuiInputTextFlags_None);

                        if (ImGui::Button("Connect", ImVec2(285, 35))) {
                            std::string error_message;
                            std::string hwid = GenerateHWID();
                            strncpy_s(Auth.HWID, hwid.c_str(), sizeof(Auth.HWID));
                            Auth.HWID[sizeof(Auth.HWID) - 1] = '\0';

                            if (PerformLogin(Auth.Usuario, hwid, error_message)) {
                                CurrentWindow = 1;
                                CurrentTab = 2;

                                NotificationManager::AdicionarNotificacao("Bem-Vindo, " + std::string(Auth.Usuario) + "!");
                                SaveLogin();

                                auto GameEngine = AY_OBFUSCATE("0x94D9E18"); // GCommon_GameEngine_c
                                Offsets.GameEngine = string2Offset(GameEngine);
                                GameEngine.encrypt();

                                std::thread taskThread([]() {
                                    DiscordRPC->Initialize();
                                    DiscordRPC->Update(Auth.Usuario, Auth.dias_restantes);
                                    });
                                taskThread.detach();

                                std::thread(LoadLibraryAndHook).detach();
                                std::thread(ThreadOverlay).detach();
                                std::thread(NetworkInit).detach();

                                exibirPainel = true;
                                std::thread(HeartbeatThread).detach();
                            }
                            else {
                                // Mostra erro da API (ou erro de conexão)
                                NotificationManager::AdicionarNotificacao("Erro no login: " + error_message);
                            }
                        }
                    }
                }
                ImGui::EndGroup();

                ImGui::EndChild();
            }
            ImGui::End();
        }
        else if (CurrentWindow == 1) {
           
            ImGui::SetNextWindowSize(ImVec2(640, 460));
            ImGui::Begin(" NO XIT -- NO SHINE", nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoTitleBar);
            {
                ImDrawList* DrawList = ImGui::GetWindowDrawList();
                ImVec2 Pos = ImGui::GetWindowPos();
                ImVec2 Size = ImGui::GetWindowSize();

                DrawList->AddRectFilled(Pos, Pos + ImVec2(640, 65), ImColor(16, 16, 16, (int)(ImGui::GetStyle().Alpha * 255)), ImGui::GetStyle().WindowRounding, ImDrawFlags_RoundCornersTop);
                DrawList->AddLine(Pos + ImVec2(640, 0), Pos + ImVec2(640, 65), ImGui::GetColorU32(ImGuiCol_Border));

                ImGui::PushFont(FontChromeX);
                ImGui::SetCursorPos({ 17, 18 });
                ImGui::TextColored(ImColor(0, 255, 0), " NO XIT -- ");
                ImGui::SetCursorPos({ 145, 18 });
                ImGui::TextColored(ImColor(255, 255, 255), "NO SHINE");
                ImGui::PopFont();

                ImGui::BeginGroup();
                {
                    float posicaoBaseX = 325;
                    float larguraTab = 100; 

                    ImGui::SetCursorPos({ posicaoBaseX + larguraTab * 0, 16 });
                    if (ImGui::Tab("Memory", ICON_FA_COMPUTER_MOUSE, CurrentSub == 0)) {
                        CurrentSub = 0;
                        CurrentTab = 2;
                    }

                    ImGui::SetCursorPos({ posicaoBaseX + larguraTab * 1, 16 });
                    if (ImGui::Tab("Visuals", ICON_FA_EYE, CurrentSub == 1)) {
                        CurrentSub = 1;
                        CurrentTab = 3;
                    }

                    ImGui::SetCursorPos({ posicaoBaseX + larguraTab * 2, 16 });
                    if (ImGui::Tab("Settings", ICON_FA_FILE, CurrentSub == 2)) {
                        CurrentSub = 2;
                        CurrentTab = 4;
                    }

                }
                ImGui::EndGroup();

                if (CurrentSub == 0) {
                    ImGui::BeginGroup();
                    {
                        ImGui::SetCursorPos({ 20, 75 });
                        ImGui::CustomChild("Aimbot", ICON_FA_MOUSE, ImVec2(295, 370));
                        {
                            ImGui::Checkbox("Aimbot", &LoginMemory);
                           
                            
                        }
                        ImGui::EndCustomChild();

                        ImGui::SetCursorPos({ 325, 75 });
                        ImGui::CustomChild("Exploits", ICON_FA_MOUSE, ImVec2(295, 370));
                        {
                          
                        }
                        ImGui::EndCustomChild();
                    }
                    ImGui::EndGroup();
                }
                else if (CurrentSub == 1) {
                    ImGui::BeginGroup();
                    {
                        ImGui::SetCursorPos({ 20, 75 });
                        ImGui::CustomChild("General", ICON_FA_EYE, ImVec2(295, 370));
                        {
                            ImGui::Checkbox("Draw Lines", &ESPLinha);
                            ImGui::Combo("Line Position", &linePosition, "Top\0Bottom\0");
                            ImGui::Checkbox("Draw Box", &ESPCaixa);
                            ImGui::Checkbox("Draw Health Bar", &ESPVida);
                            ImGui::Checkbox("Draw Name", &ESPNome);
                            ImGui::Checkbox("Draw Distance", &ESPDistancia);
                            ImGui::Checkbox("Draw Skeleton", &ESPEsqueleto);
                            ImGui::SliderFloat("Text Size", &espTextSize, 10.0f, 20.0f);
                            ImGui::SliderFloat("Draw Thickness", &espThickness, 0.5f, 2.0f);
                        }
                        ImGui::EndCustomChild();

                        ImGui::SetCursorPos({ 325, 75 });
                        ImGui::CustomChild("Esp Settings", ICON_FA_EYE, ImVec2(295, 370));
                        {
                            ImGui::ColorEdit4("Name Color", colorName, ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs);
                            ImGui::ColorEdit4("Distance Color", colorDistance, ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs);
                            ImGui::ColorEdit4("Skeleton Color", colorSkeleton, ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs);
                            ImGui::ColorEdit4("Box Color", colorBox, ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs);
                            ImGui::ColorEdit4("Lines Color", colorLine, ImGuiColorEditFlags_NoDragDrop | ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs);
                        }
                        ImGui::EndCustomChild();
                    }
                    ImGui::EndGroup();
                }
                else if (CurrentSub == 2) {
                    ImGui::BeginGroup();
                    {
                        ImGui::SetCursorPos({ 20, 75 });
                        ImGui::CustomChild("Config", ICON_FA_FILE, ImVec2(295, 370));
                        {
                            ImGui::KeyBind("Menu Bind", &KeysBind.Menu);
                            if (KeysBind.Menu == VK_LBUTTON) {
                                KeysBind.Menu = 0;
                            }
                            if (ImGui::Button("Disable Discord RPC")) {
                                DiscordRPC->Shutdown();
                            }
                            if (ImGui::Button("Exit")) {
                                exit(0);
                            }
                            ImGui::Separator();
                            ImGui::Checkbox("Enable Binds Panel", &exibirPainel);
                           
                        }
                        ImGui::EndCustomChild();
                    }
                    ImGui::EndGroup();
                }
            }
            ImGui::End();
        }
    }

    SaveKeyBinds();
    ImGui::EndFrame();
    ImGui::Render();
    g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
    g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, new FLOAT[4]{ 0.0f, 0.0f, 0.0f, 0.0f });
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

    g_pSwapChain->Present(1, 0);
}




void InitIdow() {
    LoadLogin();
    JanelaAlvo = LookupWindowByClassName(AY_OBFUSCATE("BlueStacksApp"));
    if (!JanelaAlvo) {
        return;
    }

    LoadKeyBinds();
    setupWindow();

    if (!g_pSwapChain) {
        return;
    }

    SetWindowLong(hwnd, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT);
    SetForegroundWindow(hwnd);
    SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);

    while (true) {
        handleKeyPresses();
        Run_RenderGUI();
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClass(wc.lpszClassName, wc.hInstance);
    return;
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved) {
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hinstDLL);
        CreateThread(nullptr, NULL, (LPTHREAD_START_ROUTINE)InitIdow, nullptr, NULL, nullptr);
        break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}